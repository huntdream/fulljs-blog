# The Backend

* Expess
* MongoDB

# Tips

* using JWT for authentication
* fetch api is really really nice when you are not familiar with it :(
* CORS
*
